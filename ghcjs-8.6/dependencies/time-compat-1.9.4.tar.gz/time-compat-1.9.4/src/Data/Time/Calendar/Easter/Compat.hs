module Data.Time.Calendar.Easter.Compat (
    sundayAfter,
    orthodoxPaschalMoon,orthodoxEaster,
    gregorianPaschalMoon,gregorianEaster
    )where

import Data.Time.Orphans ()

import Data.Time.Calendar.Easter
