# `th-orphans`
[![Hackage](https://img.shields.io/hackage/v/th-orphans.svg)][Hackage: th-orphans]
[![Hackage Dependencies](https://img.shields.io/hackage-deps/v/th-orphans.svg)](http://packdeps.haskellers.com/reverse/th-orphans)
[![Haskell Programming Language](https://img.shields.io/badge/language-Haskell-blue.svg)][Haskell.org]
[![BSD3 License](http://img.shields.io/badge/license-BSD3-brightgreen.svg)][tl;dr Legal: BSD3]
[![Build](https://img.shields.io/travis/mgsloan/th-orphans.svg)](https://travis-ci.org/mgsloan/th-orphans)

[Hackage: th-orphans]:
  http://hackage.haskell.org/package/th-orphans
  "th-orphans package on Hackage"
[Haskell.org]:
  http://www.haskell.org
  "The Haskell Programming Language"
[tl;dr Legal: BSD3]:
  https://tldrlegal.com/license/bsd-3-clause-license-%28revised%29
  "BSD 3-Clause License (Revised)"

Orphan instances for TH datatypes
