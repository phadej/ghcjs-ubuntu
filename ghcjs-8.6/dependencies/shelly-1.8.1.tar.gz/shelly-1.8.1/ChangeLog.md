# 1.8.1

There is a new function `cp_should_follow_symlinks` to specify whether a copy should follow symlinks.

# 1.8.0

* `cp_r` now uses upper case R: `cp -R`

# 1.7.2

* Support exceptions-0.9

# 1.7.0.1

* Fix FindSpec.hs tests. Fixes [#150](https://github.com/yesodweb/Shelly.hs/issues/150), [#162](https://github.com/yesodweb/Shelly.hs/issues/162)

# 1.6.8.7

* Relax unix-compat constraints

# 1.6.8.6

* Fix Build issue [#156](https://github.com/yesodweb/Shelly.hs/issues/156)

# 1.6.8.5

* Fix Windows build [#155](https://github.com/yesodweb/Shelly.hs/pull/155)

# 1.6.8

* added sshPairsWithOptions function

# 1.6.7

* flush stdout when using `echo`, not just `echo_n`
* fix should be able to silence stderr when using `runHandle`
* expose RunFailed

# 1.6.6

* add prependToPath function

# 1.6.5

* expose MonadShControl

# 1.6.4.1

* add writeBinary function
