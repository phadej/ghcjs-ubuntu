#!/bin/sh
echo "starting"
sleep 2
echo "finished"
