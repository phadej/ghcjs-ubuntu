byteable
=======

Documentation: [byteable on hackage](http://hackage.haskell.org/package/byteable)
