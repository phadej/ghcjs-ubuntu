{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.IORef.Compat (
  module Base
) where

import "base-compat" Data.IORef.Compat as Base
