{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Either.Compat (
  module Base
) where

import "base-compat" Data.Either.Compat as Base
