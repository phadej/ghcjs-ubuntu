{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.STRef.Compat (
  module Base
) where

import "base-compat" Data.STRef.Compat as Base
