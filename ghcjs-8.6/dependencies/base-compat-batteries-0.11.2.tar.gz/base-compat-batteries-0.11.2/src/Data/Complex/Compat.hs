{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Complex.Compat (
  module Base
) where

import "base-compat" Data.Complex.Compat as Base
