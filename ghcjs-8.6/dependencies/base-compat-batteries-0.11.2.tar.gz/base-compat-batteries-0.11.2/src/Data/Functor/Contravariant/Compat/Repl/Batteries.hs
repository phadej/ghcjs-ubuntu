{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Data.Functor.Contravariant.Compat"
-- from a globally unique namespace.
module Data.Functor.Contravariant.Compat.Repl.Batteries (
  module Data.Functor.Contravariant.Compat
) where
import "this" Data.Functor.Contravariant.Compat
