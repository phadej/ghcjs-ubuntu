{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Functor.Const.Compat (
  module Base
) where

import "base-compat" Data.Functor.Const.Compat as Base
