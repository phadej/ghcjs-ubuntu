{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Data.Functor.Product.Compat"
-- from a globally unique namespace.
module Data.Functor.Product.Compat.Repl.Batteries (
  module Data.Functor.Product.Compat
) where
import "this" Data.Functor.Product.Compat
