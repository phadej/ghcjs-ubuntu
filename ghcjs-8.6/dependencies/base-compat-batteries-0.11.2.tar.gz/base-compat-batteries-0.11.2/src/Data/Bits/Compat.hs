{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Bits.Compat (
  module Base
) where

import "base-compat" Data.Bits.Compat as Base
