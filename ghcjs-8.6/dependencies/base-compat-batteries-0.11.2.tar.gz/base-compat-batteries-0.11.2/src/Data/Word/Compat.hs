{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Word.Compat (
  module Base
) where

import "base-compat" Data.Word.Compat as Base
