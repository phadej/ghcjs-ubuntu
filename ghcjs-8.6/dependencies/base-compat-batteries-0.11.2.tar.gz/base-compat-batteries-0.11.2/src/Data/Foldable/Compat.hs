{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Foldable.Compat (
  module Base
) where

import "base-compat" Data.Foldable.Compat as Base
