{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.List.Compat (
  module Base
) where

import "base-compat" Data.List.Compat as Base
