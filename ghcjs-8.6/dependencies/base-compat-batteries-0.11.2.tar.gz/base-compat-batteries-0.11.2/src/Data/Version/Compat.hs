{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Version.Compat (
  module Base
) where

import "base-compat" Data.Version.Compat as Base
