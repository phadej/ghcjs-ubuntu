{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.String.Compat (
  module Base
) where

import "base-compat" Data.String.Compat as Base
