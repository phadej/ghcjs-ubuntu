{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Ratio.Compat (
  module Base
) where

import "base-compat" Data.Ratio.Compat as Base
