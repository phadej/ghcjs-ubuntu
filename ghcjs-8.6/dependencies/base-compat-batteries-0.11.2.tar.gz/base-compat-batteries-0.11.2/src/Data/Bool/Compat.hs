{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Bool.Compat (
  module Base
) where

import "base-compat" Data.Bool.Compat as Base
