{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Data.Function.Compat (
  module Base
) where

import "base-compat" Data.Function.Compat as Base
