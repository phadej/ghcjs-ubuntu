{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Compat (
  module Base
) where

import "base-compat" Foreign.Compat as Base
