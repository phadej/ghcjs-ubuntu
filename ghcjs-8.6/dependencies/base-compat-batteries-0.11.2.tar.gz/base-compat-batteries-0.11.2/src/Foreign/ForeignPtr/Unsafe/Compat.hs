{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.ForeignPtr.Unsafe.Compat (
  module Base
) where

import "base-compat" Foreign.ForeignPtr.Unsafe.Compat as Base
