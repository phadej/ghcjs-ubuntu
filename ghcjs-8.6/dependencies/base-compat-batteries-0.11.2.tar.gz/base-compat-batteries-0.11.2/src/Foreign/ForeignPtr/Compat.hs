{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.ForeignPtr.Compat (
  module Base
) where

import "base-compat" Foreign.ForeignPtr.Compat as Base
