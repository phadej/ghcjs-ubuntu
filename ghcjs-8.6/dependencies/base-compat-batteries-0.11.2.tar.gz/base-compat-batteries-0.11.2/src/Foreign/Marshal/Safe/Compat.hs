{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Marshal.Safe.Compat (
  module Base
) where

import "base-compat" Foreign.Marshal.Safe.Compat as Base
