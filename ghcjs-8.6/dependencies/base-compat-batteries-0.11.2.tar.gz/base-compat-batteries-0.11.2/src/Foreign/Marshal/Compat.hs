{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Marshal.Compat (
  module Base
) where

import "base-compat" Foreign.Marshal.Compat as Base
