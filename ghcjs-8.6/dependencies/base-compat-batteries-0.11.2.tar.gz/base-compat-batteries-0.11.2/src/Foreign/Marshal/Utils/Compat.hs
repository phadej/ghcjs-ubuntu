{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Marshal.Utils.Compat (
  module Base
) where

import "base-compat" Foreign.Marshal.Utils.Compat as Base
