{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Marshal.Array.Compat (
  module Base
) where

import "base-compat" Foreign.Marshal.Array.Compat as Base
