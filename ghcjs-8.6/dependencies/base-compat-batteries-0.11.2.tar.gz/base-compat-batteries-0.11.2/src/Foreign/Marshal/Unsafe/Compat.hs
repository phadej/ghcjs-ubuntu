{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Marshal.Unsafe.Compat (
  module Base
) where

import "base-compat" Foreign.Marshal.Unsafe.Compat as Base
