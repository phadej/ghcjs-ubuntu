{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Foreign.Marshal.Alloc.Compat (
  module Base
) where

import "base-compat" Foreign.Marshal.Alloc.Compat as Base
