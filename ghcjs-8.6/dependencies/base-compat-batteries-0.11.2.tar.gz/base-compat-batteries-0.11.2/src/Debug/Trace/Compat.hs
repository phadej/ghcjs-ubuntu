{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Debug.Trace.Compat (
  module Base
) where

import "base-compat" Debug.Trace.Compat as Base
