{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module System.Environment.Compat (
  module Base
) where

import "base-compat" System.Environment.Compat as Base
