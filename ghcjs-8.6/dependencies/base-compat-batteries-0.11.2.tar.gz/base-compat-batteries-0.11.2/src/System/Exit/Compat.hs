{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module System.Exit.Compat (
  module Base
) where

import "base-compat" System.Exit.Compat as Base
