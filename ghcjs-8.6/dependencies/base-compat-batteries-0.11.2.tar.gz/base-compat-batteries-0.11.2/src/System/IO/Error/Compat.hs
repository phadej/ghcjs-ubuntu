{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module System.IO.Error.Compat (
  module Base
) where

import "base-compat" System.IO.Error.Compat as Base
