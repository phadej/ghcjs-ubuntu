{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module System.IO.Unsafe.Compat (
  module Base
) where

import "base-compat" System.IO.Unsafe.Compat as Base
