{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module System.IO.Compat (
  module Base
) where

import "base-compat" System.IO.Compat as Base
