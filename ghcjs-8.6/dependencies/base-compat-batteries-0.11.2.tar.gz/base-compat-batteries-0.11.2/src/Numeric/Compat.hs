{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Numeric.Compat (
  module Base
) where

import "base-compat" Numeric.Compat as Base
