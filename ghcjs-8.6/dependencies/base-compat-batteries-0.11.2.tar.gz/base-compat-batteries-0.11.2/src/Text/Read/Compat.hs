{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Text.Read.Compat (
  module Base
) where

import "base-compat" Text.Read.Compat as Base
