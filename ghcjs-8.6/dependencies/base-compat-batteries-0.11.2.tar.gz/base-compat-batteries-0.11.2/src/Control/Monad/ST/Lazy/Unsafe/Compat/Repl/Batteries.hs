{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Control.Monad.ST.Lazy.Unsafe.Compat"
-- from a globally unique namespace.
module Control.Monad.ST.Lazy.Unsafe.Compat.Repl.Batteries (
  module Control.Monad.ST.Lazy.Unsafe.Compat
) where
import "this" Control.Monad.ST.Lazy.Unsafe.Compat
