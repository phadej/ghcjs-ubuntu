{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Control.Monad.ST.Unsafe.Compat (
  module Base
) where

import "base-compat" Control.Monad.ST.Unsafe.Compat as Base
