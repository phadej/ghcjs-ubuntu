{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Control.Monad.ST.Lazy.Unsafe.Compat (
  module Base
) where

import "base-compat" Control.Monad.ST.Lazy.Unsafe.Compat as Base
