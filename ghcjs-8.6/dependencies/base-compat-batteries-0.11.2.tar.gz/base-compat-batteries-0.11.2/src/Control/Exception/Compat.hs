{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Control.Exception.Compat (
  module Base
) where

import "base-compat" Control.Exception.Compat as Base
