{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Control.Concurrent.Compat (
  module Base
) where

import "base-compat" Control.Concurrent.Compat as Base
