{-# LANGUAGE CPP, NoImplicitPrelude, PackageImports #-}
module Control.Concurrent.MVar.Compat (
  module Base
) where

import "base-compat" Control.Concurrent.MVar.Compat as Base
