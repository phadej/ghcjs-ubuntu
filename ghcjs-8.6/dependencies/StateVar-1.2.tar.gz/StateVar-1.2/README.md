[![Hackage](https://img.shields.io/hackage/v/StateVar.svg)](https://hackage.haskell.org/package/StateVar)
[![Stackage LTS](https://www.stackage.org/package/StateVar/badge/lts)](https://www.stackage.org/lts/package/StateVar)
[![Stackage nightly](https://www.stackage.org/package/StateVar/badge/nightly)](https://www.stackage.org/nightly/package/StateVar)
[![Build Status](https://img.shields.io/travis/haskell-opengl/StateVar/master.svg)](https://travis-ci.org/haskell-opengl/StateVar)
