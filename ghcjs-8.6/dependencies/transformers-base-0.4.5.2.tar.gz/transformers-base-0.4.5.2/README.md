Transformers-Base
=================

[![Travis](https://img.shields.io/travis/mvv/transformers-base/master.svg)](https://travis-ci.org/mvv/transformers-base) [![Hackage](https://img.shields.io/hackage/v/transformers-base.svg)](http://hackage.haskell.org/package/transformers-base)

This package provides a straightforward port of [monadLib][monadLib]'s BaseM
typeclass to [transformers][transformers].

[monadLib]: http://hackage.haskell.org/package/monadLib
[transformers]: http://hackage.haskell.org/package/transformers

Installation
------------
The usual:

	$ cabal install

