#ifndef CRYPTONITE_CURVE25519_H
#define CRYPTONITE_CURVE25519_H

int cryptonite_curve25519_donna(u8 *mypublic, const u8 *secret, const u8 *basepoint);

#endif
