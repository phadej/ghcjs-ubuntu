1.0.3.1
-------

- GHC-9.0 support

1.0.3
-----

- Mark all modules `Trustworthy`. (deprecated modules are `Safe` for GHC-7.4+).

1.0.2.2
-------

- GHC-8.6.1 compatible release
- Fix compilation when `+check-bounds`

1.0.2.1
-------

- GHC-8.4.1 compatible release
- Bump dependencies' bounds

1.0.2
-----

- Deprecate `Math.NumberTheory.Power.Integer` and `Math.NumberTheory.Power.Natural` modules
  `(^)` is as good as custom methods.

1.0.1
-----

- Add support for `integer-simple`
