# integer-logarithms

[![Build Status](https://travis-ci.org/Bodigrim/integer-logarithms.svg?branch=master)](https://travis-ci.org/Bodigrim/integer-logarithms)

`Math.NumberTheory.Logarithms` splitted out of [`arithmoi`](http://hackage.haskell.org/package/arithmoi)
