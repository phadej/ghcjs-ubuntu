#!/usr/bin/env runhaskell
import Distribution.Simple
main = defaultMain
