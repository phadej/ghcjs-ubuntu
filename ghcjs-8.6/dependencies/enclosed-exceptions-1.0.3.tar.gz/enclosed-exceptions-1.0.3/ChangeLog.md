# ChangeLog for enclosed-exceptions

## 1.0.3

* Skip some tests on GHC 8.4 [#12](https://github.com/jcristovao/enclosed-exceptions/issues/12)

## 1.0.2.1

* Support for GHC 7.4 and earlier

## 1.0.2

* Use MVar in tryAny, drop async dependency [#9](https://github.com/jcristovao/enclosed-exceptions/pull/9)

## 1.0.1

* Added tryDeep and catchDeep
