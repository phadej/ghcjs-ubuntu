See also http://pvp.haskell.org/faq

## 0.96.0.0

- Update to `regex-base-0.94.0.0` API
- Compatibility with `base-4.13.0`
- Remove internal regex C implementation

----
