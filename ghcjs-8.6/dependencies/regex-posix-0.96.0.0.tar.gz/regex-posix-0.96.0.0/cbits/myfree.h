void hs_regex_regfree(void *);
