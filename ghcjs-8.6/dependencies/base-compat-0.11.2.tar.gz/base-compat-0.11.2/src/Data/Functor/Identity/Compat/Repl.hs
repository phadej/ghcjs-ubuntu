{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Data.Functor.Identity.Compat"
-- from a globally unique namespace.
module Data.Functor.Identity.Compat.Repl (
  module Data.Functor.Identity.Compat
) where
import "this" Data.Functor.Identity.Compat
