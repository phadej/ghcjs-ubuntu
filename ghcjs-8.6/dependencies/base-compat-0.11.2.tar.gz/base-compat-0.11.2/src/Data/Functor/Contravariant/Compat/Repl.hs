{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Data.Functor.Contravariant.Compat"
-- from a globally unique namespace.
module Data.Functor.Contravariant.Compat.Repl (
  module Data.Functor.Contravariant.Compat
) where
import "this" Data.Functor.Contravariant.Compat
