{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Data.Functor.Compose.Compat"
-- from a globally unique namespace.
module Data.Functor.Compose.Compat.Repl (
  module Data.Functor.Compose.Compat
) where
import "this" Data.Functor.Compose.Compat
