{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Data.Functor.Sum.Compat"
-- from a globally unique namespace.
module Data.Functor.Sum.Compat.Repl (
  module Data.Functor.Sum.Compat
) where
import "this" Data.Functor.Sum.Compat
