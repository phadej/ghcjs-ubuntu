{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Foreign.Marshal.Array.Compat"
-- from a globally unique namespace.
module Foreign.Marshal.Array.Compat.Repl (
  module Foreign.Marshal.Array.Compat
) where
import "this" Foreign.Marshal.Array.Compat
