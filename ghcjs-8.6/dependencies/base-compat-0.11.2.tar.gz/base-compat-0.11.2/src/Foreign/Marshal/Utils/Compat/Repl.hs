{-# LANGUAGE PackageImports #-}
{-# OPTIONS_GHC -fno-warn-dodgy-exports -fno-warn-unused-imports #-}
-- | Reexports "Foreign.Marshal.Utils.Compat"
-- from a globally unique namespace.
module Foreign.Marshal.Utils.Compat.Repl (
  module Foreign.Marshal.Utils.Compat
) where
import "this" Foreign.Marshal.Utils.Compat
