module Warning
  {-# WARNING ["You are configuring this package without cabal-doctest installed.",
               "The doctests test-suite will not work as a result.",
               "To fix this, install cabal-doctest before configuring."] #-}
  () where
