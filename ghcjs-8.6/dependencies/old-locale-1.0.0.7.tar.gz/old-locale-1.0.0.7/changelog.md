# Changelog for [`old-locale` package](http://hackage.haskell.org/package/old-locale)

## 1.0.0.7  *Nov 2014*

  * Decoupled from GHC distribution

## 1.0.0.6  *Mar 2014*

  * Bundled with GHC 7.8.1

  * Update Haddock comments

  * Update to Cabal 1.10 format

## 1.0.0.5  *Sep 2012*

  * Bundled with GHC 7.6.1

  * Un-deprecate `old-locale` package

## 1.0.0.4  *Feb 2012*

  * Bundled with GHC 7.4.1

  * Add support for SafeHaskell
