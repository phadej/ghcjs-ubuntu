# `invariant`
[![Hackage](https://img.shields.io/hackage/v/invariant.svg)][Hackage: invariant]
[![Hackage Dependencies](https://img.shields.io/hackage-deps/v/invariant.svg)](http://packdeps.haskellers.com/reverse/invariant)
[![Haskell Programming Language](https://img.shields.io/badge/language-Haskell-blue.svg)][Haskell.org]
[![BSD3 License](http://img.shields.io/badge/license-BSD3-brightgreen.svg)][tl;dr Legal: BSD3]
[![Build](https://img.shields.io/travis/nfrisby/invariant-functors.svg)](https://travis-ci.org/nfrisby/invariant-functors)

[Hackage: invariant]:
  http://hackage.haskell.org/package/invariant
  "invariant package on Hackage"
[Haskell.org]:
  http://www.haskell.org
  "The Haskell Programming Language"
[tl;dr Legal: BSD3]:
  https://tldrlegal.com/license/bsd-3-clause-license-%28revised%29
  "BSD 3-Clause License (Revised)"

Haskell98 invariant functors
