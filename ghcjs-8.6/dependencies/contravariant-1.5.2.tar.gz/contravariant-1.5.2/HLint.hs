ignore "Eta reduce"
ignore "Use const"
ignore "Use first"
