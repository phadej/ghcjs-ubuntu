#ifndef FOUNDATION_PRIM_H
#define FOUNDATION_PRIM_H
#include "Rts.h"

typedef StgInt FsOffset;
typedef StgInt FsCountOf;

#endif
