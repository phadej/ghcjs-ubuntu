module Basement.Types.CharUTF8
    ( CharUTF8(..)
    , encodeCharUTF8
    , decodeCharUTF8
    ) where

import Basement.UTF8.Types
import Basement.UTF8.Helper
