Instance of Applicative for Cofree
==================================

See [proof for the transformer version]
(../Trans/Cofree/instance-Applicative-CofreeT.md) and specialize it for the
Identity applicative functor.
