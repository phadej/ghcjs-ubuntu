Instance of Monad for Cofree
==================================

See [proof for the transformer version]
(../Trans/Cofree/instance-Monad-CofreeT.md) and specialize it for the
Identity Monad.
