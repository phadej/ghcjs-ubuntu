## system-filepath

Please see [deprecation announcement](https://plus.google.com/+MichaelSnoyman/posts/Ft5hnPqpgEx)

Provides a `FilePath` datatype and utility functions for operating on it.
Unlike the `filepath` package, this package does not simply reuse `String`,
increasing type safety.
