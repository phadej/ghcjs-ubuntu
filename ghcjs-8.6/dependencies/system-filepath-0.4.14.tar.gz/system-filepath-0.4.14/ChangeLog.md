## 0.4.14

* Add a Semigroup instance [#20 ](https://github.com/fpco/haskell-filesystem/pull/20)

## 0.4.13.3

* Documentation fix for: `PLATFORM_PATH_FORMAT` promotes platform dependent code [#12](https://github.com/fpco/haskell-filesystem/issues/12)

## 0.4.13.2

* update `splitDirectories` function [#4](https://github.com/fpco/haskell-filesystem/pull/4)

## 0.4.13.1

Allow deepseq 1.4

## 0.4.13

Maintenance taken over by FP Complete.
