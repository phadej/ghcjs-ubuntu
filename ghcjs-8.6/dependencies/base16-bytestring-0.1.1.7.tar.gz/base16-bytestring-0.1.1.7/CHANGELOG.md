# 0.1.1.7

* Fix some bugs in lazy decoding
  ([#8](https://github.com/haskell/base16-bytestring/pull/8)).

# 0.1.1.6

*  Changelog not recorded up to this version.
