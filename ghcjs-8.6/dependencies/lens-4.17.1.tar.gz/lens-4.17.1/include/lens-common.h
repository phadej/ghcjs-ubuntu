#ifndef LENS_COMMON_H
#define LENS_COMMON_H

#if __GLASGOW_HASKELL__ >= 806
# define KVS(kvs) kvs
#else
# define KVS(kvs)
#endif

#endif
