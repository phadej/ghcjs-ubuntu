ANSI Wadler/Leijen Pretty Printer
=================================

For all information on this package, please consult the [homepage][hp].

[![Build Status](https://img.shields.io/travis/ekmett/ansi-wl-pprint/master.svg?label=current%20master%20build)](https://travis-ci.org/ekmett/ansi-wl-pprint)

[hp]: http://batterseapower.github.com/ansi-wl-pprint
