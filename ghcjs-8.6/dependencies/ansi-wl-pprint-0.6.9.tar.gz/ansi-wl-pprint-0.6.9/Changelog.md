## 0.6.9

- All modules are explicitly `Safe`.
- Support GHC-7.0 ... GHC-8.8

## 0.6.8.2

- Allow `ansi-terminal-0.8`
