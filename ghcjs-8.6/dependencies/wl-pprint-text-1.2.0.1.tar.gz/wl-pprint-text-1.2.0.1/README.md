wl-pprint-text
==============

[![Hackage](https://img.shields.io/hackage/v/wl-pprint-text.svg)](https://hackage.haskell.org/package/wl-pprint-text) [![Build Status](https://travis-ci.org/ivan-m/wl-pprint-text.svg)](https://travis-ci.org/ivan-m/wl-pprint-text)

A clone of [wl-pprint](http://hackage.haskell.org/package/wl-pprint)
for use with the [text](http://hackage.haskell.org/package/text)
library (with some improved handling of whitespace).
