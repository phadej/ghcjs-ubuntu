-- | Just a re-export of @Data.Yaml@. In the future, this will be the canonical
-- name for that module\'s contents.
module Data.Yaml.Aeson
    ( module Data.Yaml
    ) where

import Data.Yaml
