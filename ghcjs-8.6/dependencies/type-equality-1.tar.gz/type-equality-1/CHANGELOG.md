## 1
  * Rewrite the library to contain a shim of recent `base` `Data.Type.Equality` module.

## 0.1.2
  * Add subst2. Thanks to James Koppel.

## 0.1.1
  * Turn on PolyKinds for GHC >= 7.6. Thanks to Ben Franksen.

## 0.1.0.2
  * Move 'Build-depends' to 'Library' section. Thanks to Brent Yorgey.

## 0.1.0.1
  * Added EqT instance for (:=:)
  * Removed 'cast' as synonym for 'coerce'.
  *  Show and read instances for (:=:).
  * Lots of small changes.

##  0.1.0
  * Initial version.
