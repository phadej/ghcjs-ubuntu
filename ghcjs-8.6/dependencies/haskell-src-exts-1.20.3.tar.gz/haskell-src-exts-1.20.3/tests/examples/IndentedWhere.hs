
f x = g
  where g :: Int
        g = 0
