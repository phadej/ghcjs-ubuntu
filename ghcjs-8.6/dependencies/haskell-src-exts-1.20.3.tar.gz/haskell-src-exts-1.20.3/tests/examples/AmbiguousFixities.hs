f = (+ 1) . head &&& tail
