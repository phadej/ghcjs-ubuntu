data X = X deriving Show
data X = X deriving (Show)
