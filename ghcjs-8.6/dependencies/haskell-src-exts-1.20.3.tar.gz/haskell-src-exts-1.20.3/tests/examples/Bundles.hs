{-# LANGUAGE PatternSynonyms #-}
module Bundles(Foo(..), Baz(..,Q), Qux(F,..), Tux(Q,..,F)) where

main = main
