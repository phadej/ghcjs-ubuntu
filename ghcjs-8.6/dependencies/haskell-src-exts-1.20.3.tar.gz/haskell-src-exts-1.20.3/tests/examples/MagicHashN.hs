{-# LANGUAGE MagicHash #-}
module MagicHashN where

a# = 1
b## = 2
c### = 3
main = print (a#, b##, c###)
