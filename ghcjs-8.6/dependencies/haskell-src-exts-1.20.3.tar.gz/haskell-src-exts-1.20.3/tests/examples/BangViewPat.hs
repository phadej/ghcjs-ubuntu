{-# LANGUAGE BangPatterns, ViewPatterns #-}
someFun (id -> !arg) = undefined
