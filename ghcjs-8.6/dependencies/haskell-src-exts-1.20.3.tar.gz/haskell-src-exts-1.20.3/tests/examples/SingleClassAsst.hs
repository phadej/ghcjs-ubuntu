module Test where

foo :: (Eq a) => a -> a
foo x = x
