{-# LANGUAGE CApiFFI #-}
foo = capi

