{-# LANGUAGE TypeOperators #-}
module DataHeadParen where

data (a1 :< a2)  = Foo
