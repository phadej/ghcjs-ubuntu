happyThen :: () => P a
