module Completesig03A where

data A = A | B

{-# COMPLETE A #-}

