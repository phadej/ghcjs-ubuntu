data T = T deriving Eq
