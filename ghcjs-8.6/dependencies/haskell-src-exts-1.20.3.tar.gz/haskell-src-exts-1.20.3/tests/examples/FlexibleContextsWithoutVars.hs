{-# LANGUAGE FlexibleContexts #-}
f :: Log.Stack => a -> a
f = id
