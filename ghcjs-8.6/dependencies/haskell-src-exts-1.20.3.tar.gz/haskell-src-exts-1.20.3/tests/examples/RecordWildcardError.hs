foo Record{..} = xs
