{-# OPTIONS_GHC
    -a
    -a
    -a
    -a
    -a
    -a
    -a
    -a
    -a
    -a
    -a #-}
main :: IO ()
main = dat
