
foo = _

foo = _ x

foo =    _

foo x = baz
  where
    foo _ = _
