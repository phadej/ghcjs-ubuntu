{-# LANGUAGE NamedFieldPuns #-}
{- -} module Main where
main = putStr "foo"
