{-# LANGUAGE QuasiQuotes #-}
[qq| abc |]
