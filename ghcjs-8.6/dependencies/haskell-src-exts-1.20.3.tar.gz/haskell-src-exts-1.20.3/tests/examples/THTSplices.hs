{-# LANGUAGE TemplateHaskell #-}
import Language.Haskell.TH
main = undefined :: $(undefined)
