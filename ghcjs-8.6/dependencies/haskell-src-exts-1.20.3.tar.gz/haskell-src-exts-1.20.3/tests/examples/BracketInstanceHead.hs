instance (Bounded a => Bounded [a]) where
