{-# INLINE CONLIKE size #-}
size :: Int
size = 64
