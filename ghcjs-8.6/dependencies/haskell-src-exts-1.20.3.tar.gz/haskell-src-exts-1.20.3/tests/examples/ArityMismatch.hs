module ArityMismatch where

foo a b = 1
foo a = 2

bar = 1
baz = 2
