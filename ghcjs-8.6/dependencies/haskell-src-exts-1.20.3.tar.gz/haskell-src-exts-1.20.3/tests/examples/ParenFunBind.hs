module ParenFunBind where

(foo x) y = x + y
