{-# LANGUAGE DoRec #-}

main = do rec let x = 1
          return ()
