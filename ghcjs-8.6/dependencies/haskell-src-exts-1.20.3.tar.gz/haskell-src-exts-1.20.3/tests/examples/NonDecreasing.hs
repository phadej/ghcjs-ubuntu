module NonDecreasing where

-- This should not work unless NondecreasingIndentation is
-- on (which is is by default in GHC)
main = do
  print 16
  do
  print 17
  print 18
