{-# ANN foo "Hlint: ignore Test4" #-}
