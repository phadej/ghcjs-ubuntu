{-# LANGUAGE NamedFieldPuns #-}
f (C {M.a}) = a

