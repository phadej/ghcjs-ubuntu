{-# LANGUAGE Trustworthy #-}
import safe Prelude as P
