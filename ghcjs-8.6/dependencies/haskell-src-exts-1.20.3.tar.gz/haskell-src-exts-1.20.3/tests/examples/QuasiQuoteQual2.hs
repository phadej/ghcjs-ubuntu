{-# LANGUAGE QuasiQuotes #-}
f [True] = 1
f _ = 0

