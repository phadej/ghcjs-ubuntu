module EmptyList where

eAttrs = []
