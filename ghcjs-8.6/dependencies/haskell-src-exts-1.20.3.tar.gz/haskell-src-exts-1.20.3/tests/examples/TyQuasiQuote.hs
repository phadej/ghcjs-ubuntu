{-# LANGUAGE QuasiQuotes, TemplateHaskell #-}
f :: [qq| something in here |]
f = ()
