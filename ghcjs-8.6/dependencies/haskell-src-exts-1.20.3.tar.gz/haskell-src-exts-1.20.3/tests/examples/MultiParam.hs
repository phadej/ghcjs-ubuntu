module MultiParam where

foo :: MonadError e m => e -> m ()
foo = undefined
