{-# LANGUAGE PackageImports #-}
module PackageImports where

import "wibble" PackageImports.Default
import "wibble" PackageImports.Builtin.All
