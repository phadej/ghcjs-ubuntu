{-# LANGUAGE TemplateHaskell #-}
t1 :: $( [t|Int|] )
t1 = 1

