{-# LANGUAGE ExplicitNamespaces #-}
module ExplicitNamespaces2 ( f, type (++) ) where

f = undefined
