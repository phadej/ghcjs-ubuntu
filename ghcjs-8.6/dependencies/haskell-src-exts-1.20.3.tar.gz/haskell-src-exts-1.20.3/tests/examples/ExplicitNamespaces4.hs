{-# LANGUAGE ExplicitNamespaces #-}
{-# LANGUAGE TypeOperators #-}
module Foo (type (:-)) where

data (:-) = Foo
