{-# LANGUAGE OverloadedLabels #-}

(#.) :: Int -> Int -> Int
x #. y = x + y

infixr 9 #.
