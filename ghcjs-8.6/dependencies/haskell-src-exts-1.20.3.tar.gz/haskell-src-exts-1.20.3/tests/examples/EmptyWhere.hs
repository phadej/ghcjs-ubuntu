foo = 5 where
