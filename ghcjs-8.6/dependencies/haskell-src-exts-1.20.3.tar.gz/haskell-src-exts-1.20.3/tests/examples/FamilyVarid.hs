{-# LANGUAGE TypeFamilies #-}
module FamilyVarid where

f family forall = undefined
