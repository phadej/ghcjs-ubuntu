{-# LANGUAGE ConstraintKinds #-}
module ContextOrdering where

foo :: (x m a) => Int
foo = 5
