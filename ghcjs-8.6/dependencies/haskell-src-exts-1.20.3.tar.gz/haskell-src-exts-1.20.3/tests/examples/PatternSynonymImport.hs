{-# LANGUAGE PatternSynonyms #-}

module Main (pattern Foo, pattern (:>)) where

import Foo (pattern Foo, pattern (:>))
