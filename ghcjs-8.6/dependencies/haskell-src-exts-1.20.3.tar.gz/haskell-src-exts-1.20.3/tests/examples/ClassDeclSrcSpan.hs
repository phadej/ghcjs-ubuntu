
class C1 a where
    toString :: a -> String

t1 :: String
t1 = "Hello"
