main = f where
    f = g where
    g = putStrLn "hello world"
