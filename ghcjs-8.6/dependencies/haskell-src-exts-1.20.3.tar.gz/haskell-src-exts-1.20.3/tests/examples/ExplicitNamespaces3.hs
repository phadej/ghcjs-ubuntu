{-# LANGUAGE ExplicitNamespaces #-}

module Foo(type Str) where

data Str = Str
