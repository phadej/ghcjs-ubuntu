{-# LANGUAGE InterruptibleFFI #-}
foo = interruptible

