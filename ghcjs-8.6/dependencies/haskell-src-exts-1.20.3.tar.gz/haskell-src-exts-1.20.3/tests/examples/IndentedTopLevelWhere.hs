module IndentedTopLevelWhere where

 foo :: Int
 foo = 5 where

 bar :: Int
 bar = 3
