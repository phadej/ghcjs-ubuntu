{-# LANGUAGE TypeFamilies #-}
module FamilyKindSig where

type family WithKindSig (a :: * -> *)
