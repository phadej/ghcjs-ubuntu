one :: a ~ Int => a
one = 1
