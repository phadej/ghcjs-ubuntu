{-# LANGUAGE NamedFieldPuns #-}
module RecordPuns where

cotile = tile {Kind.ospeedup}
