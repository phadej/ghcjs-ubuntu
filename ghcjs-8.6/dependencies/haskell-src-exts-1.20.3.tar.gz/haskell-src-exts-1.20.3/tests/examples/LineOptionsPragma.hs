{-# OPTIONS #-}
{-# LINE 49 "src/Language/C/Parser/Lexer.x" #-}
module Fail where
