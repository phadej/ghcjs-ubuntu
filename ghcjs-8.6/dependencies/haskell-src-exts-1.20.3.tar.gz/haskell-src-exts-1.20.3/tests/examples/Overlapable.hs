instance {-# OVERLAP #-} C a

instance {-# NO_OVERLAP #-} C a

instance {-# INCOHERENT #-} C a

