{-# LANGUAGE PatternSynonyms #-}

module T11727 where

pattern A,B :: Int
pattern A = 5
pattern B = 5

