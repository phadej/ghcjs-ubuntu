{-# LANGUAGE BangPatterns #-}

(!) arr i = arr i
