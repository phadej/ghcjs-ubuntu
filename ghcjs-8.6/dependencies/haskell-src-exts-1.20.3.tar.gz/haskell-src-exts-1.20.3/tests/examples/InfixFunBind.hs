left `first` _ = left
