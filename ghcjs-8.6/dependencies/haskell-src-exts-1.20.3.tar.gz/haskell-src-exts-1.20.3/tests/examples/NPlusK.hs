{-# LANGUAGE NPlusKPatterns #-}

f (n+3) = n
