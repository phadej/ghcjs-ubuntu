newtype PoC = PoC (forall b . b)
