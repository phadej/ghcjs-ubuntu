{-# language TypeOperators, KindSignatures #-}
data B = B
data a * b = Foo
type A = B * B
main = print 1
