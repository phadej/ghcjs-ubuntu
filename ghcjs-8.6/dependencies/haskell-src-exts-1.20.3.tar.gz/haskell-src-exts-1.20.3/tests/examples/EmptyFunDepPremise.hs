{-# LANGUAGE FunctionalDependencies #-}
module EmptyFunDepPremise where

class C a | -> a
