data Baz = Baz

instance Show Baz where
  show _ = ""
    where
  show _ = ""
