f :: Ord (i Int) => i Int -> i Int
f = undefined
