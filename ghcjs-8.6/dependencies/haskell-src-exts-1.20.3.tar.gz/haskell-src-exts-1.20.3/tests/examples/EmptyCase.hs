{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE LambdaCase #-}

f x = case x of {}

g x = \case {}
