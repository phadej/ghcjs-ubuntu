{-# LANGUAGE TemplateHaskell #-}

[| f :: $ty |]
[| f :: $(fun ty) |]
