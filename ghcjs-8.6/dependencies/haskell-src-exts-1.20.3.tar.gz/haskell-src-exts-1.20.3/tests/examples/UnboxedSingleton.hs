{-# LANGUAGE UnboxedTuples #-}
-- See e.g. GHC.Prim.indexArray#
foo a = (# a #)
