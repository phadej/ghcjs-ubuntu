{-# LANGUAGE
RecordWildCards
 #-}
main = print "hello"
