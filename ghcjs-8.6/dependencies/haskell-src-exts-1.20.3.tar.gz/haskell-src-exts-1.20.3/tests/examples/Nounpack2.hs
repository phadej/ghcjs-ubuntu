

data Foo = Foo {-# NOUNPACK #-} Int
