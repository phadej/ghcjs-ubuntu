import "hint" HLint.Default

ignore "Warning: Avoid lambda"
ignore "Warning: Use &&&"

