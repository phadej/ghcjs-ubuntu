module System.Posix.Types.IntWord (module IntWord) where

import Data.Int  as IntWord
import Data.Word as IntWord
