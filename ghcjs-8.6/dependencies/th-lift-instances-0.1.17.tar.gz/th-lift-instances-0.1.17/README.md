th-lift-instances
====================

[![Build Status](https://secure.travis-ci.org/bennofs/th-lift-instances.png?branch=master)](http://travis-ci.org/bennofs/th-lift-instances)

Some more Lift instances for common haskell data types.

