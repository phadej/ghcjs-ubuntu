/* -----------------------------------------------------------------------------
 *
 * Utility C functions.
 *
 * -------------------------------------------------------------------------- */

#include "HsFFI.h"

void enableTimingStats( void );
void setHeapSize( HsInt size );
