/* -----------------------------------------------------------------------------

   (c) The University of Glasgow, 1994-2004

   Native-code generator header file - just useful macros for now.

   -------------------------------------------------------------------------- */

#pragma once

#include "ghc_boot_platform.h"
