cONTROL_GROUP_CONST_291 :: DynFlags -> Int
cONTROL_GROUP_CONST_291 dflags = pc_CONTROL_GROUP_CONST_291 (sPlatformConstants (settings dflags))
sTD_HDR_SIZE :: DynFlags -> Int
sTD_HDR_SIZE dflags = pc_STD_HDR_SIZE (sPlatformConstants (settings dflags))
pROF_HDR_SIZE :: DynFlags -> Int
pROF_HDR_SIZE dflags = pc_PROF_HDR_SIZE (sPlatformConstants (settings dflags))
bLOCK_SIZE :: DynFlags -> Int
bLOCK_SIZE dflags = pc_BLOCK_SIZE (sPlatformConstants (settings dflags))
bLOCKS_PER_MBLOCK :: DynFlags -> Int
bLOCKS_PER_MBLOCK dflags = pc_BLOCKS_PER_MBLOCK (sPlatformConstants (settings dflags))
tICKY_BIN_COUNT :: DynFlags -> Int
tICKY_BIN_COUNT dflags = pc_TICKY_BIN_COUNT (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR1 :: DynFlags -> Int
oFFSET_StgRegTable_rR1 dflags = pc_OFFSET_StgRegTable_rR1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR2 :: DynFlags -> Int
oFFSET_StgRegTable_rR2 dflags = pc_OFFSET_StgRegTable_rR2 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR3 :: DynFlags -> Int
oFFSET_StgRegTable_rR3 dflags = pc_OFFSET_StgRegTable_rR3 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR4 :: DynFlags -> Int
oFFSET_StgRegTable_rR4 dflags = pc_OFFSET_StgRegTable_rR4 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR5 :: DynFlags -> Int
oFFSET_StgRegTable_rR5 dflags = pc_OFFSET_StgRegTable_rR5 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR6 :: DynFlags -> Int
oFFSET_StgRegTable_rR6 dflags = pc_OFFSET_StgRegTable_rR6 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR7 :: DynFlags -> Int
oFFSET_StgRegTable_rR7 dflags = pc_OFFSET_StgRegTable_rR7 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR8 :: DynFlags -> Int
oFFSET_StgRegTable_rR8 dflags = pc_OFFSET_StgRegTable_rR8 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR9 :: DynFlags -> Int
oFFSET_StgRegTable_rR9 dflags = pc_OFFSET_StgRegTable_rR9 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rR10 :: DynFlags -> Int
oFFSET_StgRegTable_rR10 dflags = pc_OFFSET_StgRegTable_rR10 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rF1 :: DynFlags -> Int
oFFSET_StgRegTable_rF1 dflags = pc_OFFSET_StgRegTable_rF1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rF2 :: DynFlags -> Int
oFFSET_StgRegTable_rF2 dflags = pc_OFFSET_StgRegTable_rF2 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rF3 :: DynFlags -> Int
oFFSET_StgRegTable_rF3 dflags = pc_OFFSET_StgRegTable_rF3 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rF4 :: DynFlags -> Int
oFFSET_StgRegTable_rF4 dflags = pc_OFFSET_StgRegTable_rF4 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rF5 :: DynFlags -> Int
oFFSET_StgRegTable_rF5 dflags = pc_OFFSET_StgRegTable_rF5 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rF6 :: DynFlags -> Int
oFFSET_StgRegTable_rF6 dflags = pc_OFFSET_StgRegTable_rF6 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rD1 :: DynFlags -> Int
oFFSET_StgRegTable_rD1 dflags = pc_OFFSET_StgRegTable_rD1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rD2 :: DynFlags -> Int
oFFSET_StgRegTable_rD2 dflags = pc_OFFSET_StgRegTable_rD2 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rD3 :: DynFlags -> Int
oFFSET_StgRegTable_rD3 dflags = pc_OFFSET_StgRegTable_rD3 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rD4 :: DynFlags -> Int
oFFSET_StgRegTable_rD4 dflags = pc_OFFSET_StgRegTable_rD4 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rD5 :: DynFlags -> Int
oFFSET_StgRegTable_rD5 dflags = pc_OFFSET_StgRegTable_rD5 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rD6 :: DynFlags -> Int
oFFSET_StgRegTable_rD6 dflags = pc_OFFSET_StgRegTable_rD6 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rXMM1 :: DynFlags -> Int
oFFSET_StgRegTable_rXMM1 dflags = pc_OFFSET_StgRegTable_rXMM1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rXMM2 :: DynFlags -> Int
oFFSET_StgRegTable_rXMM2 dflags = pc_OFFSET_StgRegTable_rXMM2 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rXMM3 :: DynFlags -> Int
oFFSET_StgRegTable_rXMM3 dflags = pc_OFFSET_StgRegTable_rXMM3 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rXMM4 :: DynFlags -> Int
oFFSET_StgRegTable_rXMM4 dflags = pc_OFFSET_StgRegTable_rXMM4 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rXMM5 :: DynFlags -> Int
oFFSET_StgRegTable_rXMM5 dflags = pc_OFFSET_StgRegTable_rXMM5 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rXMM6 :: DynFlags -> Int
oFFSET_StgRegTable_rXMM6 dflags = pc_OFFSET_StgRegTable_rXMM6 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rYMM1 :: DynFlags -> Int
oFFSET_StgRegTable_rYMM1 dflags = pc_OFFSET_StgRegTable_rYMM1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rYMM2 :: DynFlags -> Int
oFFSET_StgRegTable_rYMM2 dflags = pc_OFFSET_StgRegTable_rYMM2 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rYMM3 :: DynFlags -> Int
oFFSET_StgRegTable_rYMM3 dflags = pc_OFFSET_StgRegTable_rYMM3 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rYMM4 :: DynFlags -> Int
oFFSET_StgRegTable_rYMM4 dflags = pc_OFFSET_StgRegTable_rYMM4 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rYMM5 :: DynFlags -> Int
oFFSET_StgRegTable_rYMM5 dflags = pc_OFFSET_StgRegTable_rYMM5 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rYMM6 :: DynFlags -> Int
oFFSET_StgRegTable_rYMM6 dflags = pc_OFFSET_StgRegTable_rYMM6 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rZMM1 :: DynFlags -> Int
oFFSET_StgRegTable_rZMM1 dflags = pc_OFFSET_StgRegTable_rZMM1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rZMM2 :: DynFlags -> Int
oFFSET_StgRegTable_rZMM2 dflags = pc_OFFSET_StgRegTable_rZMM2 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rZMM3 :: DynFlags -> Int
oFFSET_StgRegTable_rZMM3 dflags = pc_OFFSET_StgRegTable_rZMM3 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rZMM4 :: DynFlags -> Int
oFFSET_StgRegTable_rZMM4 dflags = pc_OFFSET_StgRegTable_rZMM4 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rZMM5 :: DynFlags -> Int
oFFSET_StgRegTable_rZMM5 dflags = pc_OFFSET_StgRegTable_rZMM5 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rZMM6 :: DynFlags -> Int
oFFSET_StgRegTable_rZMM6 dflags = pc_OFFSET_StgRegTable_rZMM6 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rL1 :: DynFlags -> Int
oFFSET_StgRegTable_rL1 dflags = pc_OFFSET_StgRegTable_rL1 (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rSp :: DynFlags -> Int
oFFSET_StgRegTable_rSp dflags = pc_OFFSET_StgRegTable_rSp (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rSpLim :: DynFlags -> Int
oFFSET_StgRegTable_rSpLim dflags = pc_OFFSET_StgRegTable_rSpLim (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rHp :: DynFlags -> Int
oFFSET_StgRegTable_rHp dflags = pc_OFFSET_StgRegTable_rHp (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rHpLim :: DynFlags -> Int
oFFSET_StgRegTable_rHpLim dflags = pc_OFFSET_StgRegTable_rHpLim (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rCCCS :: DynFlags -> Int
oFFSET_StgRegTable_rCCCS dflags = pc_OFFSET_StgRegTable_rCCCS (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rCurrentTSO :: DynFlags -> Int
oFFSET_StgRegTable_rCurrentTSO dflags = pc_OFFSET_StgRegTable_rCurrentTSO (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rCurrentNursery :: DynFlags -> Int
oFFSET_StgRegTable_rCurrentNursery dflags = pc_OFFSET_StgRegTable_rCurrentNursery (sPlatformConstants (settings dflags))
oFFSET_StgRegTable_rHpAlloc :: DynFlags -> Int
oFFSET_StgRegTable_rHpAlloc dflags = pc_OFFSET_StgRegTable_rHpAlloc (sPlatformConstants (settings dflags))
oFFSET_stgEagerBlackholeInfo :: DynFlags -> Int
oFFSET_stgEagerBlackholeInfo dflags = pc_OFFSET_stgEagerBlackholeInfo (sPlatformConstants (settings dflags))
oFFSET_stgGCEnter1 :: DynFlags -> Int
oFFSET_stgGCEnter1 dflags = pc_OFFSET_stgGCEnter1 (sPlatformConstants (settings dflags))
oFFSET_stgGCFun :: DynFlags -> Int
oFFSET_stgGCFun dflags = pc_OFFSET_stgGCFun (sPlatformConstants (settings dflags))
oFFSET_Capability_r :: DynFlags -> Int
oFFSET_Capability_r dflags = pc_OFFSET_Capability_r (sPlatformConstants (settings dflags))
oFFSET_bdescr_start :: DynFlags -> Int
oFFSET_bdescr_start dflags = pc_OFFSET_bdescr_start (sPlatformConstants (settings dflags))
oFFSET_bdescr_free :: DynFlags -> Int
oFFSET_bdescr_free dflags = pc_OFFSET_bdescr_free (sPlatformConstants (settings dflags))
oFFSET_bdescr_blocks :: DynFlags -> Int
oFFSET_bdescr_blocks dflags = pc_OFFSET_bdescr_blocks (sPlatformConstants (settings dflags))
oFFSET_bdescr_flags :: DynFlags -> Int
oFFSET_bdescr_flags dflags = pc_OFFSET_bdescr_flags (sPlatformConstants (settings dflags))
sIZEOF_CostCentreStack :: DynFlags -> Int
sIZEOF_CostCentreStack dflags = pc_SIZEOF_CostCentreStack (sPlatformConstants (settings dflags))
oFFSET_CostCentreStack_mem_alloc :: DynFlags -> Int
oFFSET_CostCentreStack_mem_alloc dflags = pc_OFFSET_CostCentreStack_mem_alloc (sPlatformConstants (settings dflags))
oFFSET_CostCentreStack_scc_count :: DynFlags -> Int
oFFSET_CostCentreStack_scc_count dflags = pc_OFFSET_CostCentreStack_scc_count (sPlatformConstants (settings dflags))
oFFSET_StgHeader_ccs :: DynFlags -> Int
oFFSET_StgHeader_ccs dflags = pc_OFFSET_StgHeader_ccs (sPlatformConstants (settings dflags))
oFFSET_StgHeader_ldvw :: DynFlags -> Int
oFFSET_StgHeader_ldvw dflags = pc_OFFSET_StgHeader_ldvw (sPlatformConstants (settings dflags))
sIZEOF_StgSMPThunkHeader :: DynFlags -> Int
sIZEOF_StgSMPThunkHeader dflags = pc_SIZEOF_StgSMPThunkHeader (sPlatformConstants (settings dflags))
oFFSET_StgEntCounter_allocs :: DynFlags -> Int
oFFSET_StgEntCounter_allocs dflags = pc_OFFSET_StgEntCounter_allocs (sPlatformConstants (settings dflags))
oFFSET_StgEntCounter_allocd :: DynFlags -> Int
oFFSET_StgEntCounter_allocd dflags = pc_OFFSET_StgEntCounter_allocd (sPlatformConstants (settings dflags))
oFFSET_StgEntCounter_registeredp :: DynFlags -> Int
oFFSET_StgEntCounter_registeredp dflags = pc_OFFSET_StgEntCounter_registeredp (sPlatformConstants (settings dflags))
oFFSET_StgEntCounter_link :: DynFlags -> Int
oFFSET_StgEntCounter_link dflags = pc_OFFSET_StgEntCounter_link (sPlatformConstants (settings dflags))
oFFSET_StgEntCounter_entry_count :: DynFlags -> Int
oFFSET_StgEntCounter_entry_count dflags = pc_OFFSET_StgEntCounter_entry_count (sPlatformConstants (settings dflags))
sIZEOF_StgUpdateFrame_NoHdr :: DynFlags -> Int
sIZEOF_StgUpdateFrame_NoHdr dflags = pc_SIZEOF_StgUpdateFrame_NoHdr (sPlatformConstants (settings dflags))
sIZEOF_StgMutArrPtrs_NoHdr :: DynFlags -> Int
sIZEOF_StgMutArrPtrs_NoHdr dflags = pc_SIZEOF_StgMutArrPtrs_NoHdr (sPlatformConstants (settings dflags))
oFFSET_StgMutArrPtrs_ptrs :: DynFlags -> Int
oFFSET_StgMutArrPtrs_ptrs dflags = pc_OFFSET_StgMutArrPtrs_ptrs (sPlatformConstants (settings dflags))
oFFSET_StgMutArrPtrs_size :: DynFlags -> Int
oFFSET_StgMutArrPtrs_size dflags = pc_OFFSET_StgMutArrPtrs_size (sPlatformConstants (settings dflags))
sIZEOF_StgSmallMutArrPtrs_NoHdr :: DynFlags -> Int
sIZEOF_StgSmallMutArrPtrs_NoHdr dflags = pc_SIZEOF_StgSmallMutArrPtrs_NoHdr (sPlatformConstants (settings dflags))
oFFSET_StgSmallMutArrPtrs_ptrs :: DynFlags -> Int
oFFSET_StgSmallMutArrPtrs_ptrs dflags = pc_OFFSET_StgSmallMutArrPtrs_ptrs (sPlatformConstants (settings dflags))
sIZEOF_StgArrBytes_NoHdr :: DynFlags -> Int
sIZEOF_StgArrBytes_NoHdr dflags = pc_SIZEOF_StgArrBytes_NoHdr (sPlatformConstants (settings dflags))
oFFSET_StgArrBytes_bytes :: DynFlags -> Int
oFFSET_StgArrBytes_bytes dflags = pc_OFFSET_StgArrBytes_bytes (sPlatformConstants (settings dflags))
oFFSET_StgTSO_alloc_limit :: DynFlags -> Int
oFFSET_StgTSO_alloc_limit dflags = pc_OFFSET_StgTSO_alloc_limit (sPlatformConstants (settings dflags))
oFFSET_StgTSO_cccs :: DynFlags -> Int
oFFSET_StgTSO_cccs dflags = pc_OFFSET_StgTSO_cccs (sPlatformConstants (settings dflags))
oFFSET_StgTSO_stackobj :: DynFlags -> Int
oFFSET_StgTSO_stackobj dflags = pc_OFFSET_StgTSO_stackobj (sPlatformConstants (settings dflags))
oFFSET_StgStack_sp :: DynFlags -> Int
oFFSET_StgStack_sp dflags = pc_OFFSET_StgStack_sp (sPlatformConstants (settings dflags))
oFFSET_StgStack_stack :: DynFlags -> Int
oFFSET_StgStack_stack dflags = pc_OFFSET_StgStack_stack (sPlatformConstants (settings dflags))
oFFSET_StgUpdateFrame_updatee :: DynFlags -> Int
oFFSET_StgUpdateFrame_updatee dflags = pc_OFFSET_StgUpdateFrame_updatee (sPlatformConstants (settings dflags))
oFFSET_StgFunInfoExtraFwd_arity :: DynFlags -> Int
oFFSET_StgFunInfoExtraFwd_arity dflags = pc_OFFSET_StgFunInfoExtraFwd_arity (sPlatformConstants (settings dflags))
sIZEOF_StgFunInfoExtraRev :: DynFlags -> Int
sIZEOF_StgFunInfoExtraRev dflags = pc_SIZEOF_StgFunInfoExtraRev (sPlatformConstants (settings dflags))
oFFSET_StgFunInfoExtraRev_arity :: DynFlags -> Int
oFFSET_StgFunInfoExtraRev_arity dflags = pc_OFFSET_StgFunInfoExtraRev_arity (sPlatformConstants (settings dflags))
mAX_SPEC_SELECTEE_SIZE :: DynFlags -> Int
mAX_SPEC_SELECTEE_SIZE dflags = pc_MAX_SPEC_SELECTEE_SIZE (sPlatformConstants (settings dflags))
mAX_SPEC_AP_SIZE :: DynFlags -> Int
mAX_SPEC_AP_SIZE dflags = pc_MAX_SPEC_AP_SIZE (sPlatformConstants (settings dflags))
mIN_PAYLOAD_SIZE :: DynFlags -> Int
mIN_PAYLOAD_SIZE dflags = pc_MIN_PAYLOAD_SIZE (sPlatformConstants (settings dflags))
mIN_INTLIKE :: DynFlags -> Int
mIN_INTLIKE dflags = pc_MIN_INTLIKE (sPlatformConstants (settings dflags))
mAX_INTLIKE :: DynFlags -> Int
mAX_INTLIKE dflags = pc_MAX_INTLIKE (sPlatformConstants (settings dflags))
mIN_CHARLIKE :: DynFlags -> Int
mIN_CHARLIKE dflags = pc_MIN_CHARLIKE (sPlatformConstants (settings dflags))
mAX_CHARLIKE :: DynFlags -> Int
mAX_CHARLIKE dflags = pc_MAX_CHARLIKE (sPlatformConstants (settings dflags))
mUT_ARR_PTRS_CARD_BITS :: DynFlags -> Int
mUT_ARR_PTRS_CARD_BITS dflags = pc_MUT_ARR_PTRS_CARD_BITS (sPlatformConstants (settings dflags))
mAX_Vanilla_REG :: DynFlags -> Int
mAX_Vanilla_REG dflags = pc_MAX_Vanilla_REG (sPlatformConstants (settings dflags))
mAX_Float_REG :: DynFlags -> Int
mAX_Float_REG dflags = pc_MAX_Float_REG (sPlatformConstants (settings dflags))
mAX_Double_REG :: DynFlags -> Int
mAX_Double_REG dflags = pc_MAX_Double_REG (sPlatformConstants (settings dflags))
mAX_Long_REG :: DynFlags -> Int
mAX_Long_REG dflags = pc_MAX_Long_REG (sPlatformConstants (settings dflags))
mAX_XMM_REG :: DynFlags -> Int
mAX_XMM_REG dflags = pc_MAX_XMM_REG (sPlatformConstants (settings dflags))
mAX_Real_Vanilla_REG :: DynFlags -> Int
mAX_Real_Vanilla_REG dflags = pc_MAX_Real_Vanilla_REG (sPlatformConstants (settings dflags))
mAX_Real_Float_REG :: DynFlags -> Int
mAX_Real_Float_REG dflags = pc_MAX_Real_Float_REG (sPlatformConstants (settings dflags))
mAX_Real_Double_REG :: DynFlags -> Int
mAX_Real_Double_REG dflags = pc_MAX_Real_Double_REG (sPlatformConstants (settings dflags))
mAX_Real_XMM_REG :: DynFlags -> Int
mAX_Real_XMM_REG dflags = pc_MAX_Real_XMM_REG (sPlatformConstants (settings dflags))
mAX_Real_Long_REG :: DynFlags -> Int
mAX_Real_Long_REG dflags = pc_MAX_Real_Long_REG (sPlatformConstants (settings dflags))
rESERVED_C_STACK_BYTES :: DynFlags -> Int
rESERVED_C_STACK_BYTES dflags = pc_RESERVED_C_STACK_BYTES (sPlatformConstants (settings dflags))
rESERVED_STACK_WORDS :: DynFlags -> Int
rESERVED_STACK_WORDS dflags = pc_RESERVED_STACK_WORDS (sPlatformConstants (settings dflags))
aP_STACK_SPLIM :: DynFlags -> Int
aP_STACK_SPLIM dflags = pc_AP_STACK_SPLIM (sPlatformConstants (settings dflags))
wORD_SIZE :: DynFlags -> Int
wORD_SIZE dflags = pc_WORD_SIZE (sPlatformConstants (settings dflags))
dOUBLE_SIZE :: DynFlags -> Int
dOUBLE_SIZE dflags = pc_DOUBLE_SIZE (sPlatformConstants (settings dflags))
cINT_SIZE :: DynFlags -> Int
cINT_SIZE dflags = pc_CINT_SIZE (sPlatformConstants (settings dflags))
cLONG_SIZE :: DynFlags -> Int
cLONG_SIZE dflags = pc_CLONG_SIZE (sPlatformConstants (settings dflags))
cLONG_LONG_SIZE :: DynFlags -> Int
cLONG_LONG_SIZE dflags = pc_CLONG_LONG_SIZE (sPlatformConstants (settings dflags))
bITMAP_BITS_SHIFT :: DynFlags -> Int
bITMAP_BITS_SHIFT dflags = pc_BITMAP_BITS_SHIFT (sPlatformConstants (settings dflags))
tAG_BITS :: DynFlags -> Int
tAG_BITS dflags = pc_TAG_BITS (sPlatformConstants (settings dflags))
wORDS_BIGENDIAN :: DynFlags -> Bool
wORDS_BIGENDIAN dflags = pc_WORDS_BIGENDIAN (sPlatformConstants (settings dflags))
dYNAMIC_BY_DEFAULT :: DynFlags -> Bool
dYNAMIC_BY_DEFAULT dflags = pc_DYNAMIC_BY_DEFAULT (sPlatformConstants (settings dflags))
lDV_SHIFT :: DynFlags -> Int
lDV_SHIFT dflags = pc_LDV_SHIFT (sPlatformConstants (settings dflags))
iLDV_CREATE_MASK :: DynFlags -> Integer
iLDV_CREATE_MASK dflags = pc_ILDV_CREATE_MASK (sPlatformConstants (settings dflags))
iLDV_STATE_CREATE :: DynFlags -> Integer
iLDV_STATE_CREATE dflags = pc_ILDV_STATE_CREATE (sPlatformConstants (settings dflags))
iLDV_STATE_USE :: DynFlags -> Integer
iLDV_STATE_USE dflags = pc_ILDV_STATE_USE (sPlatformConstants (settings dflags))
