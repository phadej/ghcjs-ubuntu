See [`haddock`'s changelog](https://hackage.haskell.org/package/haddock/changelog).
